package com.fdmgroup.model;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import antlr.collections.List;

public class Runner {
	private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("ItemPU");
	private static EntityManager em = emf.createEntityManager();

	public static void main(String[] args) {

		Department Academy = new Department("Academy");
		Department Sales = new Department("Sales");
		Employee employee1 = new Employee("John Doe", "Trainer", Academy);
		Employee employee2 = new Employee("Jane Doe", "Executive", Sales);
		Employee employee3 = new Employee("James Smith", "Trainer", Academy);

		em.getTransaction().begin();

		em.persist(Academy);
		em.persist(Sales);

		em.merge(employee1);
		em.merge(employee2);
		em.merge(employee3);

		em.getTransaction().commit();
		em.close();
	}

	private static void searchByAcademy(String pattern) {
		em = emf.createEntityManager();
		em.getTransaction().begin();
		java.util.List<Department> allMovies = em.createNamedQuery("Movie.FindAll", Department.class).getResultList();
		ArrayList<Department> results = new ArrayList<Department>();
		for (Department m : allMovies) {
			if ((m.getDeptName().toUpperCase()).contains((pattern.toUpperCase()))) {
				results.add(m);
			}
		}
		em.close();
		for (Department m : results) {
			System.out.println(m);
		}
	}

}
